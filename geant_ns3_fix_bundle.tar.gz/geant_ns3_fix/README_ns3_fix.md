# GEANT NS-3 simulation: fixed version

Replaces the experiment in `ns3_source/geant-cnn-lstm-multiflow.cc`.  The old file and its saved
XMLs are untouched; everything here is new (`geant-te-sim.cc` + helper scripts).

## What was wrong and what changed

| # | Problem in the old simulation | Fix |
|---|---|---|
| 1 | Baseline used **hop-count** routing; real GEANT uses IGP metrics (172 of 506 OD paths differ) | IGP shortest path from `geant_link_capacities.csv` |
| 2 | Every link had a flat **5 ms** delay | Per-link propagation delay (`--delay-model=geo`; `uniform` still available) |
| 3 | Only **4 hand-picked flows**; the forecast load was never actually present | Whole 23x23 matrix injected as UDP traffic, one flow per OD pair (about 400 flows) |
| 4 | Forecast was **one static snapshot** (`ns3_forecast.csv` = `pred_test[0]`) | A window of consecutive intervals replayed back to back; routes recomputed at each boundary |
| 5 | "Baseline" was not reactive, so it didn't match the Python study | Four controllers on identical traffic: `static`, `reactive` (last observed matrix = `true[t-4]`), `proactive` (forecast), `oracle` (true) |
| 6 | No congestion, so **no differences were possible**; zero jitter | `--cap-scale 0.5 / 0.35` stress scenarios (same ones as the Python study); real queues and drops |
| 7 | "Aggregate delay" summed per-packet delays | Mean / p50 / p95 / p99 delay, jitter, loss, per-interval peak link utilisation, route changes, IGP stretch |
| 8 | No failure event, no way to inspect routes | `--fail=u-v --fail-at=s` really takes both interfaces down; `--route-log` writes every OD path per interval; `--pcap-node` |
| 9 | Stress-run XMLs missing | FlowMonitor XML + per-link/per-interval CSVs saved for every run (`results/packet_grid/`) |

Also fixed while validating (these changed the results, so they are worth knowing about):
* `Ipv4AddressHelper::Assign` silently installs a default **FqCoDel** queue disc.  It is removed, so every
  router port is a plain DropTail FIFO (`--queue-pkts`, default 100).
* The controller picks a plan only if its own estimate says it is better than IGP (overflow objective, as in the
  Python study), acts only above a trigger (`--trigger`, default 0.55) and keeps the previous plan unless the new one
  is clearly better (`--hysteresis`).

## Files

| File | Purpose |
|---|---|
| `ns3_source/geant-te-sim.cc` | The simulator (tested with ns-3.44) |
| `export_ns3_trace.py` | Builds `geant_sim_links.csv` and `tm_trace.csv` from the repo's existing `.npy` / CSV files |
| `run_ns3_experiments.sh` | 4 controllers x 3 capacity scenarios for one input window |
| `analyze_ns3_results.py` | Merges the summary CSVs into markdown tables |
| `results/` | Everything produced for this report |

## How to run

```bash
# 1. inputs (from the repo root; window = 8 consecutive 15-min test intervals)
python3 export_ns3_trace.py --repo /path/to/comp_net2 --out ns3_input/peak   --window peak
python3 export_ns3_trace.py --repo /path/to/comp_net2 --out ns3_input/median --window median

# 2. build: copy geant-te-sim.cc into <ns-3>/scratch/ and
./ns3 build scratch/geant-te-sim

# 3. run (bash; run from the folder that contains ns3_input/; the executable name/path depends on your ns-3 version,
#    I only built and ran it directly with g++ against the 3.44 libraries)
./run_ns3_experiments.sh <ns-3>/build/scratch/ns3.44-geant-te-sim-default ns3_out ns3_input/peak   peak
./run_ns3_experiments.sh <ns-3>/build/scratch/ns3.44-geant-te-sim-default ns3_out ns3_input/median med
python3 analyze_ns3_results.py ns3_out

# single run, e.g. a link failure with pcap on node 20
geant-te-sim --mode=proactive --fail=10-20 --fail-at=0.6 --pcap-node=20 --route-log=routes.csv --out=ns3_out --tag=demo
# controller comparison over ALL 1601 test intervals without packets (seconds, not hours)
python3 export_ns3_trace.py --repo ... --out ns3_input/full --len 1601 --window index --index 0
geant-te-sim --plan-only --intervals=1601 --links=ns3_input/full/geant_sim_links.csv --trace=ns3_input/full/tm_trace.csv --out=ns3_out
```
Each packet run takes about 2 minutes.  `ns3 run` / `./ns3 build` use your own ns-3 install; I built against the
ns-3.44 binaries from the `ns3` PyPI wheel with `g++ -std=c++20 -I<wheel>/include` (do not add `-I.../include/ns3`:
it shadows the system `string.h`).

## Validation done

* The **old** simulator was rebuilt and reproduced the repo's saved output exactly (20,286,768 bytes;
  313.78 s baseline vs 313.77 s proactive aggregate delay), which confirms the earlier "no difference" finding.
* The new static (IGP) baseline reproduces the Python study: mean per-direction peak utilisation over the 1601 test
  intervals is **0.4918** (repo reports 0.492), p95 0.725 (repo 0.725).
* Measured per-link utilisation in NS-3 matches the model prediction from the same matrices: the mean measured/expected
  ratio over loaded links is 1.0016 / 0.9986 / 0.9995 for the first three intervals; the worst single link is about 7 %
  low (small flows are quantised into whole packets).
* Same seed gives bit-identical output (re-ran one cell).  Offered packet counts are identical across the four
  controllers in every scenario (checked automatically by `analyze_ns3_results.py`).
* Failure test: link 10-20 goes down at t = 1.6 s; 6,568 packets (0.70 %) are lost during the 50 ms before routes are
  recomputed (26 hit the down interface, 6,542 had no route), then traffic recovers.

## Results (8 intervals x 0.25 s each, 1 seed, 2 windows)

Windows: `peak` = test intervals 1425-1432 (heaviest, mean static peak util 0.79); `med` = 242-249 (typical, 0.47).
Full tables: `results/ns3_results_summary.md`.

| Scenario | Controller | Loss % | Mean delay ms | Mean peak util | Route changes / interval | IGP stretch |
|---|---|---|---|---|---|---|
| med, archived caps | all four | 0.000 | 8.489 | 0.467 | 0 | 1.000 |
| med, caps x0.5 | static | 0.000 | 8.498 | 0.935 | 0 | 1.000 |
| | reactive / proactive / oracle | 0.000 | 8.77 / 8.76 / 8.76 | 0.614 | 6.6 / 0.4 / 1.6 | 1.010 |
| med, caps x0.35 | static | **5.956** | 8.785 | 1.000 | 0 | 1.000 |
| | reactive | **0.005** | 9.177 | 0.892 | 6.3 | 1.026 |
| | proactive | **0.005** | 9.207 | 0.892 | 5.6 | 1.026 |
| | oracle | **0.005** | 9.055 | 0.868 | 0 | 1.008 |
| peak, archived caps / x0.5 | all four | 0.000 / 2.350 | 10.53 / 10.74 | 0.795 / 1.000 | 0 | 1.000 |
| peak, caps x0.35 | static / reactive / oracle | 7.426 | 10.802 | 1.000 | 0 | 1.000 |
| | proactive | 6.528 | 10.938 | 1.000 | 15.1 | 1.002 |

Over all 1601 intervals (plan-only, mean peak utilisation under the true load):

| Capacity | static | reactive | proactive | oracle |
|---|---|---|---|---|
| archived | 0.4918 | 0.4904 | 0.4916 | 0.4891 |
| x0.5 | 0.9836 | 0.9242 | 0.9242 | 0.9179 |
| x0.35 | 1.4051 | 1.3200 | 1.3216 | 1.3090 |

## What the results do and do not show

* With archived capacities nothing is overloaded in either window, so **all controllers lose nothing and look the same**.
  This is the honest outcome, not a bug (same conclusion as the Python study).
* Under capacity stress the simulator now shows real differences: in the typical window a load-aware controller cuts
  loss from about 6 % to about 0.005 %, at the cost of 1-3 % longer IGP paths (+0.3-0.4 ms mean delay).
* **A forecast advantage is not shown.**  Proactive and reactive give the same loss in the typical window; the oracle is
  only better on route churn and queueing.  In the heaviest window the proactive loss is lower at x0.35 (6.5 % vs 7.4 %),
  but that is one window and one seed.
* In the heaviest window the bottleneck is the two 155 Mbps access links of node 16 (il1), which cannot be bypassed.
  No routing change can fix that, so every controller ties.
* The controller routes by destination (link weights), which is weaker than the Python study's per-flow k=5 router
  (Python reactive mean peak 0.41 vs 0.49 here).  Per-flow paths would need per-OD destination aliases; not done.

## Assumptions and limits

* Traffic is constant-rate UDP per OD pair per interval (no burstiness, no TCP).  Each 15-minute matrix is replayed
  for 0.25 s at its true rate (time-compressed); 0.1 s of interval-0 warm-up precedes measurement.
* Propagation delays come from city-level coordinates (great circle x 1.3 / 200 km per ms), not real fibre routes.
  de1 and de2 are both placed in Frankfurt.
* Capacities are the archived 2004 values; the x0.5 and x0.35 scenarios are synthetic.
* Failure recovery is a fixed IGP reconvergence delay (`--fail-reroute-ms`, default 50).  No precomputed backups exist,
  so the test cannot favour proactive control by construction.
* Only 2 windows and 1 seed (the seed only changes packet phase offsets).  Treat results as exploratory.
* Written for ns-3.44; not built against other versions.
