# GEANT NS-3 controller comparison

## med_cap100  (capacity x1, 8 intervals x 0.25 s, delay model geo, seed 1, failure: none)

Offered packets identical across modes: **yes** (982,789 packets)

| mode | loss % | mean delay ms | mean queueing ms | p99 ms | mean peak util | max peak util | intervals >95% | lost pkts | route chg/int | IGP stretch |
|---|---|---|---|---|---|---|---|---|---|---|
| static | 0.000 | 8.489 | 0.0004 | 46.0 | 0.467 | 0.477 | 0 | 0 | 0.0 | 1.0000 |
| reactive | 0.000 | 8.489 | 0.0004 | 46.0 | 0.467 | 0.477 | 0 | 0 | 0.0 | 1.0000 |
| proactive | 0.000 | 8.489 | 0.0004 | 46.0 | 0.467 | 0.477 | 0 | 0 | 0.0 | 1.0000 |
| oracle | 0.000 | 8.489 | 0.0004 | 46.0 | 0.467 | 0.477 | 0 | 0 | 0.0 | 1.0000 |

Difference vs reactive (negative = better for every column shown):

| mode | loss_pct | mean_delay_ms | mean_excess_delay_ms | p99_ms | mean_peak_util | lost_pkts |
|---|---|---|---|---|---|---|
| static | +0.0000 | +0.0000 | +0.0000 | +0.0000 | +0.0000 | +0.0000 |
| proactive | +0.0000 | +0.0000 | +0.0000 | +0.0000 | +0.0000 | +0.0000 |
| oracle | +0.0000 | +0.0000 | +0.0000 | +0.0000 | +0.0000 | +0.0000 |

## med_cap35  (capacity x0.35, 8 intervals x 0.25 s, delay model geo, seed 1, failure: none)

Offered packets identical across modes: **yes** (982,789 packets)

| mode | loss % | mean delay ms | mean queueing ms | p99 ms | mean peak util | max peak util | intervals >95% | lost pkts | route chg/int | IGP stretch |
|---|---|---|---|---|---|---|---|---|---|---|
| static | 5.956 | 8.785 | 0.2367 | 46.0 | 1.000 | 1.000 | 8 | 58534 | 0.0 | 1.0000 |
| reactive | 0.005 | 9.177 | 0.1903 | 46.5 | 0.892 | 1.000 | 3 | 47 | 6.3 | 1.0256 |
| proactive | 0.005 | 9.207 | 0.1709 | 46.5 | 0.892 | 1.000 | 3 | 47 | 5.6 | 1.0259 |
| oracle | 0.005 | 9.055 | 0.0198 | 46.5 | 0.868 | 1.000 | 3 | 47 | 0.0 | 1.0078 |

Difference vs reactive (negative = better for every column shown):

| mode | loss_pct | mean_delay_ms | mean_excess_delay_ms | p99_ms | mean_peak_util | lost_pkts |
|---|---|---|---|---|---|---|
| static | +5.9511 | -0.3912 | +0.0463 | -0.5000 | +0.1084 | +58487.0000 |
| proactive | +0.0000 | +0.0300 | -0.0194 | +0.0000 | +0.0000 | +0.0000 |
| oracle | +0.0000 | -0.1212 | -0.1705 | +0.0000 | -0.0238 | +0.0000 |

## med_cap50  (capacity x0.5, 8 intervals x 0.25 s, delay model geo, seed 1, failure: none)

Offered packets identical across modes: **yes** (982,789 packets)

| mode | loss % | mean delay ms | mean queueing ms | p99 ms | mean peak util | max peak util | intervals >95% | lost pkts | route chg/int | IGP stretch |
|---|---|---|---|---|---|---|---|---|---|---|
| static | 0.000 | 8.498 | 0.0030 | 46.0 | 0.935 | 0.954 | 2 | 0 | 0.0 | 1.0000 |
| reactive | 0.000 | 8.766 | 0.0104 | 46.5 | 0.614 | 0.773 | 0 | 0 | 6.6 | 1.0098 |
| proactive | 0.000 | 8.757 | 0.0014 | 46.5 | 0.614 | 0.773 | 0 | 0 | 0.4 | 1.0095 |
| oracle | 0.000 | 8.763 | 0.0050 | 46.5 | 0.614 | 0.773 | 0 | 0 | 1.6 | 1.0095 |

Difference vs reactive (negative = better for every column shown):

| mode | loss_pct | mean_delay_ms | mean_excess_delay_ms | p99_ms | mean_peak_util | lost_pkts |
|---|---|---|---|---|---|---|
| static | +0.0000 | -0.2679 | -0.0074 | -0.5000 | +0.3205 | +0.0000 |
| proactive | +0.0000 | -0.0091 | -0.0091 | +0.0000 | +0.0000 | +0.0000 |
| oracle | +0.0000 | -0.0029 | -0.0055 | +0.0000 | +0.0000 | +0.0000 |

## peak_cap100  (capacity x1, 8 intervals x 0.25 s, delay model geo, seed 1, failure: none)

Offered packets identical across modes: **yes** (1,776,017 packets)

| mode | loss % | mean delay ms | mean queueing ms | p99 ms | mean peak util | max peak util | intervals >95% | lost pkts | route chg/int | IGP stretch |
|---|---|---|---|---|---|---|---|---|---|---|
| static | 0.000 | 10.530 | 0.0007 | 46.0 | 0.795 | 0.815 | 0 | 0 | 0.0 | 1.0000 |
| reactive | 0.000 | 10.530 | 0.0007 | 46.0 | 0.795 | 0.815 | 0 | 0 | 0.0 | 1.0000 |
| proactive | 0.000 | 10.530 | 0.0007 | 46.0 | 0.795 | 0.815 | 0 | 0 | 0.0 | 1.0000 |
| oracle | 0.000 | 10.530 | 0.0007 | 46.0 | 0.795 | 0.815 | 0 | 0 | 0.0 | 1.0000 |

Difference vs reactive (negative = better for every column shown):

| mode | loss_pct | mean_delay_ms | mean_excess_delay_ms | p99_ms | mean_peak_util | lost_pkts |
|---|---|---|---|---|---|---|
| static | +0.0000 | +0.0000 | +0.0000 | +0.0000 | +0.0000 | +0.0000 |
| proactive | +0.0000 | +0.0000 | +0.0000 | +0.0000 | +0.0000 | +0.0000 |
| oracle | +0.0000 | +0.0000 | +0.0000 | +0.0000 | +0.0000 | +0.0000 |

## peak_cap35  (capacity x0.35, 8 intervals x 0.25 s, delay model geo, seed 1, failure: none)

Offered packets identical across modes: **yes** (1,776,017 packets)

| mode | loss % | mean delay ms | mean queueing ms | p99 ms | mean peak util | max peak util | intervals >95% | lost pkts | route chg/int | IGP stretch |
|---|---|---|---|---|---|---|---|---|---|---|
| static | 7.426 | 10.802 | 0.3485 | 46.0 | 1.000 | 1.000 | 8 | 131879 | 0.0 | 1.0000 |
| reactive | 7.426 | 10.802 | 0.3485 | 46.0 | 1.000 | 1.000 | 8 | 131879 | 0.0 | 1.0000 |
| proactive | 6.528 | 10.938 | 0.5349 | 46.5 | 1.000 | 1.000 | 8 | 115935 | 15.1 | 1.0021 |
| oracle | 7.426 | 10.802 | 0.3485 | 46.0 | 1.000 | 1.000 | 8 | 131879 | 0.0 | 1.0000 |

Difference vs reactive (negative = better for every column shown):

| mode | loss_pct | mean_delay_ms | mean_excess_delay_ms | p99_ms | mean_peak_util | lost_pkts |
|---|---|---|---|---|---|---|
| static | +0.0000 | +0.0000 | +0.0000 | +0.0000 | +0.0000 | +0.0000 |
| proactive | -0.8977 | +0.1361 | +0.1864 | +0.5000 | +0.0000 | -15944.0000 |
| oracle | +0.0000 | +0.0000 | +0.0000 | +0.0000 | +0.0000 | +0.0000 |

## peak_cap50  (capacity x0.5, 8 intervals x 0.25 s, delay model geo, seed 1, failure: none)

Offered packets identical across modes: **yes** (1,776,017 packets)

| mode | loss % | mean delay ms | mean queueing ms | p99 ms | mean peak util | max peak util | intervals >95% | lost pkts | route chg/int | IGP stretch |
|---|---|---|---|---|---|---|---|---|---|---|
| static | 2.350 | 10.738 | 0.2388 | 46.0 | 1.000 | 1.000 | 8 | 41734 | 0.0 | 1.0000 |
| reactive | 2.350 | 10.738 | 0.2388 | 46.0 | 1.000 | 1.000 | 8 | 41734 | 0.0 | 1.0000 |
| proactive | 2.350 | 10.738 | 0.2388 | 46.0 | 1.000 | 1.000 | 8 | 41734 | 0.0 | 1.0000 |
| oracle | 2.350 | 10.738 | 0.2388 | 46.0 | 1.000 | 1.000 | 8 | 41734 | 0.0 | 1.0000 |

Difference vs reactive (negative = better for every column shown):

| mode | loss_pct | mean_delay_ms | mean_excess_delay_ms | p99_ms | mean_peak_util | lost_pkts |
|---|---|---|---|---|---|---|
| static | +0.0000 | +0.0000 | +0.0000 | +0.0000 | +0.0000 | +0.0000 |
| proactive | +0.0000 | +0.0000 | +0.0000 | +0.0000 | +0.0000 | +0.0000 |
| oracle | +0.0000 | +0.0000 | +0.0000 | +0.0000 | +0.0000 | +0.0000 |

