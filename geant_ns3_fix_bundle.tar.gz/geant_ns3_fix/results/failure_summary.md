# GEANT NS-3 controller comparison

## fail1020  (capacity x1, 4 intervals x 0.25 s, delay model geo, seed 1, failure: 10-20)

Offered packets identical across modes: **yes** (934,318 packets)

| mode | loss % | mean delay ms | mean queueing ms | p99 ms | mean peak util | max peak util | intervals >95% | lost pkts | route chg/int | IGP stretch |
|---|---|---|---|---|---|---|---|---|---|---|
| static | 0.703 | 10.911 | 0.4715 | 46.0 | 0.701 | 0.804 | 0 | 6568 | 0.0 | 1.0000 |
| proactive | 0.703 | 10.911 | 0.4715 | 46.0 | 0.701 | 0.804 | 0 | 6568 | 0.0 | 1.0000 |

