#!/usr/bin/env python3
"""Export the inputs the fixed NS-3 simulator (geant-te-sim.cc) needs.

Writes, into --out (default: ns3_input/):
  geant_sim_links.csv  one row per link: node indices, source ids, capacity (kbps),
                       IGP metric, approximate distance and one-way propagation delay
  tm_trace.csv         time series of 23x23 matrices for a window of consecutive
                       test intervals: kinds  true | forecast | observed
                       (observed[i] is the last matrix the reactive controller had
                       seen, i.e. true[i-4]; forecast[i] is the stack's 1-hour-ahead
                       prediction for interval i)
  trace_meta.json      which window was chosen and why

Everything is read from the repo's existing files; nothing is re-trained.
"""
import argparse
import csv
import json
import math
import os

import numpy as np

# Approximate PoP locations, keyed by the source ids used in geant_link_capacities.csv.
# ASSUMPTION: city-level coordinates (the repo does not contain fibre route lengths).
# de1 and de2 are joined by an IGP metric of 1, so both are placed in Frankfurt.
POP_COORDS = {
    "se1": ("Stockholm", 59.33, 18.07),
    "nl1": ("Amsterdam", 52.37, 4.90),
    "be1": ("Brussels", 50.85, 4.35),
    "ie1": ("Dublin", 53.35, -6.26),
    "hr1": ("Zagreb", 45.81, 15.98),
    "pt1": ("Lisbon", 38.72, -9.14),
    "ny1": ("New York", 40.71, -74.01),
    "ch1": ("Geneva", 46.20, 6.14),
    "si1": ("Ljubljana", 46.06, 14.51),
    "it1": ("Milan", 45.46, 9.19),
    "de1": ("Frankfurt", 50.11, 8.68),
    "de2": ("Frankfurt", 50.11, 8.68),
    "pl1": ("Poznan", 52.41, 16.93),
    "fr1": ("Paris", 48.86, 2.35),
    "uk1": ("London", 51.51, -0.13),
    "lu1": ("Luxembourg", 49.61, 6.13),
    "at1": ("Vienna", 48.21, 16.37),
    "il1": ("Tel Aviv", 32.09, 34.78),
    "cz1": ("Prague", 50.08, 14.44),
    "gr1": ("Athens", 37.98, 23.73),
    "hu1": ("Budapest", 47.50, 19.04),
    "es1": ("Madrid", 40.42, -3.70),
    "sk1": ("Bratislava", 48.15, 17.11),
}
FIBRE_KM_PER_MS = 200.0  # ~2e8 m/s in glass
N = 23


def haversine_km(a, b):
    la1, lo1, la2, lo2 = map(math.radians, (a[0], a[1], b[0], b[1]))
    h = math.sin((la2 - la1) / 2) ** 2 + math.cos(la1) * math.cos(la2) * math.sin((lo2 - lo1) / 2) ** 2
    return 2 * 6371.0 * math.asin(math.sqrt(h))


def dijkstra_trees(links, weights):
    """next-hop link index nh[dst][node], destination-rooted, deterministic ties."""
    adj = [[] for _ in range(N)]
    for i, (u, v) in enumerate(links):
        adj[u].append((i, v))
        adj[v].append((i, u))
    nh = np.full((N, N), -1, dtype=int)
    import heapq
    for d in range(N):
        dist = [math.inf] * N
        dist[d] = 0.0
        pq = [(0.0, d)]
        while pq:
            c, u = heapq.heappop(pq)
            if c > dist[u]:
                continue
            for li, nb in adj[u]:
                nd = c + weights[li]
                if nd < dist[nb] - 1e-9:
                    dist[nb] = nd
                    nh[d][nb] = li
                    heapq.heappush(pq, (nd, nb))
    return nh


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--repo", default=".", help="repo root (contains geant_link_capacities.csv, res_STACK_BEST/)")
    ap.add_argument("--results", default="res_STACK_BEST", help="folder with true/pred/last_observed_test.npy")
    ap.add_argument("--out", default="ns3_input")
    ap.add_argument("--len", type=int, default=8, help="number of consecutive 15-min intervals to replay")
    ap.add_argument("--window", choices=["peak", "median", "index"], default="peak",
                    help="peak: window with highest mean static-IGP peak utilisation; "
                         "median: window closest to the median; index: use --index")
    ap.add_argument("--index", type=int, default=0)
    ap.add_argument("--route-factor", type=float, default=1.3, help="fibre route length / great-circle distance")
    a = ap.parse_args()

    res = os.path.join(a.repo, a.results)
    T = np.load(os.path.join(res, "true_test.npy")).astype(np.float64)
    P = np.load(os.path.join(res, "pred_test.npy")).astype(np.float64)
    L = np.load(os.path.join(res, "last_observed_test.npy")).astype(np.float64)
    n_t = T.shape[0]

    lag_ok = bool(np.allclose(L[4:], T[:-4]))
    print(f"last_observed[i] == true[i-4] for all i>=4: {lag_ok}")

    # --- links -------------------------------------------------------------
    rows = list(csv.DictReader(open(os.path.join(a.repo, "geant_link_capacities.csv"))))
    ids = {}
    links, cap, igp, dist_km, delay_ms = [], [], [], [], []
    for r in rows:
        u, v = int(r["u_idx"]), int(r["v_idx"])
        ids[u], ids[v] = r["u_source_id"], r["v_source_id"]
        links.append((u, v))
        cap.append(float(r["capacity_kbps"]))
        igp.append(float(r["igp_metric"]))
    for (u, v) in links:
        cu, cv = POP_COORDS[ids[u]], POP_COORDS[ids[v]]
        d = haversine_km((cu[1], cu[2]), (cv[1], cv[2]))
        dist_km.append(d)
        delay_ms.append(max(0.1, d * a.route_factor / FIBRE_KM_PER_MS))
    os.makedirs(a.out, exist_ok=True)
    with open(os.path.join(a.out, "geant_sim_links.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["u", "v", "u_id", "v_id", "capacity_kbps", "igp_metric", "distance_km", "delay_ms"])
        for (u, v), c, m, d, dl in zip(links, cap, igp, dist_km, delay_ms):
            w.writerow([u, v, ids[u], ids[v], f"{c:.0f}", f"{m:.0f}", f"{d:.1f}", f"{dl:.3f}"])
    print(f"links: {len(links)}; propagation delay range {min(delay_ms):.2f}-{max(delay_ms):.2f} ms")

    # --- static IGP peak utilisation per interval (per-direction, like the Python study) ---
    nh = dijkstra_trees(links, igp)
    pair_idx = {}
    A = np.zeros((2 * len(links), N * N))
    for s in range(N):
        for d in range(N):
            if s == d:
                continue
            node = s
            while node != d:
                li = nh[d][node]
                u, v = links[li]
                direction = 0 if node == u else 1
                A[2 * li + direction, s * N + d] = 1.0
                node = v if node == u else u
    cap_dir = np.repeat(np.array(cap), 2)
    util = (A @ T.reshape(n_t, -1).T) / cap_dir[:, None]
    peak = util.max(axis=0)
    print(f"static IGP peak util over test set: mean {peak.mean():.3f}  p95 {np.percentile(peak, 95):.3f}  max {peak.max():.3f}")

    # --- window ------------------------------------------------------------
    k = a.len
    win_mean = np.array([peak[i:i + k].mean() for i in range(n_t - k + 1)])
    if a.window == "peak":
        t0 = int(win_mean.argmax())
    elif a.window == "median":
        t0 = int(np.abs(win_mean - np.median(win_mean)).argmin())
    else:
        t0 = a.index
    t0 = max(0, min(t0, n_t - k))
    print(f"window: test intervals {t0}..{t0 + k - 1} ({a.window}); mean static peak util {peak[t0:t0 + k].mean():.3f}")

    with open(os.path.join(a.out, "tm_trace.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["interval", "kind", "src", "dst", "kbps"])
        for i in range(k):
            t = t0 + i
            for kind, M in (("true", T), ("forecast", P), ("observed", L)):
                for s in range(N):
                    for d in range(N):
                        if s != d and M[t, s, d] > 0:
                            w.writerow([i, kind, s, d, f"{M[t, s, d]:.3f}"])
    meta = {
        "window_mode": a.window, "test_index_start": t0, "intervals": k,
        "mean_static_peak_util_window": float(peak[t0:t0 + k].mean()),
        "mean_static_peak_util_all": float(peak.mean()),
        "observed_equals_true_lag4": lag_ok,
        "delay_model": f"great-circle x {a.route_factor} / {FIBRE_KM_PER_MS} km per ms (city-level coordinates, ASSUMPTION)",
        "total_offered_Gbps_per_interval": [float(T[t0 + i].sum() / 1e6) for i in range(k)],
    }
    json.dump(meta, open(os.path.join(a.out, "trace_meta.json"), "w"), indent=2)
    print("wrote", os.path.join(a.out, "tm_trace.csv"), "and trace_meta.json")


if __name__ == "__main__":
    main()
