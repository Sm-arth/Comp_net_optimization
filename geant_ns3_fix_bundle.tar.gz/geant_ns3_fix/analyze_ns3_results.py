#!/usr/bin/env python3
"""Merge the *.summary.csv files written by geant-te-sim into markdown tables.

  python3 analyze_ns3_results.py <out-dir> [more-out-dirs ...]

For every scenario tag it prints one table (one row per controller) plus a
difference table against the reactive controller, and checks that every mode
saw exactly the same offered traffic.  Writes <out-dir>/ns3_results_summary.md.
"""
import csv
import glob
import os
import sys
from collections import defaultdict

MODE_ORDER = ["static", "reactive", "proactive", "oracle"]
COLS = [
    ("loss_pct", "loss %", "{:.3f}"),
    ("mean_delay_ms", "mean delay ms", "{:.3f}"),
    ("mean_excess_delay_ms", "mean queueing ms", "{:.4f}"),
    ("p99_ms", "p99 ms", "{:.1f}"),
    ("mean_peak_util", "mean peak util", "{:.3f}"),
    ("max_peak_util", "max peak util", "{:.3f}"),
    ("intervals_peak_gt95", "intervals >95%", "{:.0f}"),
    ("lost_pkts", "lost pkts", "{:.0f}"),
    ("route_changes_per_interval", "route chg/int", "{:.1f}"),
    ("igp_stretch", "IGP stretch", "{:.4f}"),
]
DIFF = ["loss_pct", "mean_delay_ms", "mean_excess_delay_ms", "p99_ms", "mean_peak_util", "lost_pkts"]


def load(dirs):
    runs = defaultdict(dict)
    for d in dirs:
        for f in sorted(glob.glob(os.path.join(d, "*.summary.csv"))):
            with open(f) as fh:
                for row in csv.DictReader(fh):
                    runs[row["tag"]][row["mode"]] = row
    return runs


def table(rows, cols, header_first="mode"):
    out = ["| " + " | ".join([header_first] + [c[1] for c in cols]) + " |",
           "|" + "---|" * (len(cols) + 1)]
    for m in MODE_ORDER:
        if m in rows:
            r = rows[m]
            out.append("| " + " | ".join([m] + [c[2].format(float(r[c[0]])) for c in cols]) + " |")
    return "\n".join(out)


def main():
    dirs = sys.argv[1:] or ["ns3_out"]
    runs = load(dirs)
    if not runs:
        sys.exit("no *.summary.csv found in " + ", ".join(dirs))
    md = ["# GEANT NS-3 controller comparison", ""]
    for tag in sorted(runs):
        rows = runs[tag]
        any_row = next(iter(rows.values()))
        tx = {m: int(r["tx_pkts"]) for m, r in rows.items()}
        same = len(set(tx.values())) == 1
        md.append(f"## {tag}  (capacity x{any_row['cap_scale']}, {any_row['intervals']} intervals x "
                  f"{any_row['interval_sec']} s, delay model {any_row['delay_model']}, seed {any_row['seed']}, "
                  f"failure: {any_row['fail']})")
        md.append("")
        md.append(f"Offered packets identical across modes: **{'yes' if same else 'NO - ' + str(tx)}** "
                  f"({next(iter(tx.values())):,} packets)")
        md.append("")
        md.append(table(rows, COLS))
        md.append("")
        if "reactive" in rows:
            ref = rows["reactive"]
            md.append("Difference vs reactive (negative = better for every column shown):")
            md.append("")
            md.append("| mode | " + " | ".join(c for c in DIFF) + " |")
            md.append("|" + "---|" * (len(DIFF) + 1))
            for m in MODE_ORDER:
                if m in rows and m != "reactive":
                    md.append("| " + m + " | " + " | ".join(
                        f"{float(rows[m][c]) - float(ref[c]):+.4f}" for c in DIFF) + " |")
            md.append("")
    text = "\n".join(md)
    print(text)
    with open(os.path.join(dirs[0], "ns3_results_summary.md"), "w") as f:
        f.write(text + "\n")


if __name__ == "__main__":
    main()
