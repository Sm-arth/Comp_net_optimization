#!/usr/bin/env bash
# Packet-level controller comparison on the fixed GEANT simulator.
#
#   ./run_ns3_experiments.sh <built geant-te-sim> <out-dir> <input-dir> <tag-prefix> [jobs]
#
# <input-dir> is what export_ns3_trace.py wrote (geant_sim_links.csv + tm_trace.csv).
# Runs 4 controllers x 3 capacity scenarios.  Same trace and RNG seed in every run, so the
# offered traffic is identical across controllers.
#   <prefix>_cap100  archived 2004 GEANT capacities
#   <prefix>_cap50   every link at 50 %  (synthetic stress, as in the Python study)
#   <prefix>_cap35   every link at 35 %  (synthetic stress)
#
# Example:
#   python3 export_ns3_trace.py --repo ~/comp_net2 --out ns3_input/peak --window peak
#   python3 export_ns3_trace.py --repo ~/comp_net2 --out ns3_input/median --window median
#   ./run_ns3_experiments.sh build/geant-te-sim ns3_out ns3_input/peak peak
#   ./run_ns3_experiments.sh build/geant-te-sim ns3_out ns3_input/median median
#   python3 analyze_ns3_results.py ns3_out
set -euo pipefail

SIM=${1:?usage: $0 <geant-te-sim binary> <out-dir> <input-dir> <tag-prefix> [jobs]}
OUT=${2:?out-dir}
IN=${3:?input-dir}
PFX=${4:?tag-prefix}
JOBS=${5:-2}
mkdir -p "$OUT"
export SIM OUT IN

run() { # tag mode cap-scale
  "$SIM" --tag="$1" --mode="$2" --cap-scale="$3" --out="$OUT" \
         --links="$IN/geant_sim_links.csv" --trace="$IN/tm_trace.csv" \
         --route-log="$OUT/$1_$2.routes.csv" > "$OUT/$1_$2.log" 2>&1
  echo "done $1 $2"
}
export -f run

for spec in "cap100 1.0" "cap50 0.5" "cap35 0.35"; do
  set -- $spec
  for mode in static reactive proactive oracle; do
    echo "run ${PFX}_$1 $mode $2"
  done
done | xargs -P "$JOBS" -I{} bash -c "{}"
